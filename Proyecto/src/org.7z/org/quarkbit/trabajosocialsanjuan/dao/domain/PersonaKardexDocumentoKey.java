package org.quarkbit.trabajosocialsanjuan.dao.domain;

public class PersonaKardexDocumentoKey {
    /**
     *
     * column personas_kardex_documentos.codigo_kardex
     *
     * 
     */
    private Integer codigoKardex;

    /**
     *
     * column personas_kardex_documentos.codigo_documento
     *
     * 
     */
    private Integer codigoDocumento;

    /**
     * 
     *column personas_kardex_documentos.codigo_kardex
     *
     * @return the value of personas_kardex_documentos.codigo_kardex
     *
     * 
     */
    public Integer getCodigoKardex() {
        return codigoKardex;
    }

    /**
     * 
     *  column personas_kardex_documentos.codigo_kardex
     *
     * @param codigoKardex the value for personas_kardex_documentos.codigo_kardex
     *
     * 
     */
    public void setCodigoKardex(Integer codigoKardex) {
        this.codigoKardex = codigoKardex;
    }

    /**
     * 
     *column personas_kardex_documentos.codigo_documento
     *
     * @return the value of personas_kardex_documentos.codigo_documento
     *
     * 
     */
    public Integer getCodigoDocumento() {
        return codigoDocumento;
    }

    /**
     * 
     *  column personas_kardex_documentos.codigo_documento
     *
     * @param codigoDocumento the value for personas_kardex_documentos.codigo_documento
     *
     * 
     */
    public void setCodigoDocumento(Integer codigoDocumento) {
        this.codigoDocumento = codigoDocumento;
    }
}